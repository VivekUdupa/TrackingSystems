
#include <stdio.h>
#include <math.h>
#include <windows.h>
#include <sys/timeb.h>
#include <time.h>


		/*
		** Robot functions
		*/



		/* This robot moves randomly */

void RandomRobot(int FoodClosestDistance,	/* input - closest food in pixels */
			int FoodClosestAngle,		/* input - angle in degrees towards closest food */
			int RobotClosestDistance,	/* input - closest other robot, in pixels */
			int RobotClosestAngle,		/* input - angle in degrees towards closest robot */
			int SharkClosestDistance,	/* input - closest shark in pixels */
			int SharkClosestAngle,		/* input - angle in degrees towards closest shark */
			int CurrentRobotEnergy,		/* input - this robot's current energy (50 - 255) */
			int *RobotMoveAngle,		/* output - angle in degrees to move */
			int *RobotExpendEnergy)		/* output - energy to expend in motion (cannot exceed Current-50) */

{
(*RobotMoveAngle)=(rand() % 360);
if (CurrentRobotEnergy > 50)
  (*RobotExpendEnergy)=(rand() % (CurrentRobotEnergy-50));
else
  (*RobotExpendEnergy)=1;
if ((*RobotExpendEnergy) > 10)
  (*RobotExpendEnergy)=10;
}



		/* This robot moves towards food, ignoring sharks */

void GreedyRobot(int FoodClosestDistance,	/* input - closest food in pixels */
			int FoodClosestAngle,		/* input - angle in degrees towards closest food */
			int RobotClosestDistance,	/* input - closest other robot, in pixels */
			int RobotClosestAngle,		/* input - angle in degrees towards closest robot */
			int SharkClosestDistance,	/* input - closest shark in pixels */
			int SharkClosestAngle,		/* input - angle in degrees towards closest shark */
			int CurrentRobotEnergy,		/* input - this robot's current energy (50 - 255) */
			int *RobotMoveAngle,		/* output - angle in degrees to move */
			int *RobotExpendEnergy)		/* output - energy to expend in motion (cannot exceed Current-50) */

{
(*RobotMoveAngle)=FoodClosestAngle;
(*RobotExpendEnergy)=30;
}



		/* This robot moves away from sharks, ignoring food */

void ScaredRobot(int FoodClosestDistance,	/* input - closest food in pixels */
			int FoodClosestAngle,		/* input - angle in degrees towards closest food */
			int RobotClosestDistance,	/* input - closest other robot, in pixels */
			int RobotClosestAngle,		/* input - angle in degrees towards closest robot */
			int SharkClosestDistance,	/* input - closest shark in pixels */
			int SharkClosestAngle,		/* input - angle in degrees towards closest shark */
			int CurrentRobotEnergy,		/* input - this robot's current energy (50 - 255) */
			int *RobotMoveAngle,		/* output - angle in degrees to move */
			int *RobotExpendEnergy)		/* output - energy to expend in motion (cannot exceed Current-50) */

{
(*RobotMoveAngle)=(180+SharkClosestAngle)%360;
if (SharkClosestDistance < 30)
  (*RobotExpendEnergy)=30;
else
  (*RobotExpendEnergy)=30-SharkClosestDistance/10;
if ((*RobotExpendEnergy) < 3)
  (*RobotExpendEnergy)=3;
}

void VicTron(int FoodClosestDistance,	/* input - closest food in pixels */
	int FoodClosestAngle,		/* input - angle in degrees towards closest food */
	int RobotClosestDistance,	/* input - closest other robot, in pixels */
	int RobotClosestAngle,		/* input - angle in degrees towards closest robot */
	int SharkClosestDistance,	/* input - closest shark in pixels */
	int SharkClosestAngle,		/* input - angle in degrees towards closest shark */
	int CurrentRobotEnergy,		/* input - this robot's current energy (50 - 255) */
	int *RobotMoveAngle,		/* output - angle in degrees to move */
	int *RobotExpendEnergy)		/* output - energy to expend in motion (cannot exceed Current-50) */

{
	// Define the Trigger Points
	//static int MoveAngle = 2;
	int RunFromShark = 80; //Closest a shark can get
	int MinEnergy = 20; //Energy below which hunger strikes 
	int RunForFood = 100; //Run when food gets this close
	int PersonalBubble = 5; //When other bots come too close, run away!
	static int prevAngle = 180; //Static to store previous value for next cycle
	int angleInc = 30; //Angle Increment step

	/*Priorities:
	When energy is high:
	1: Move away from the shark!!! scary shark
	2: Go for food! Yumm
	3: Do not get blocked by other robots! 
	4: Just slowly move around looking for food
	When energy is low:
	1: Go to the closest food! Hungry!!
	2: Run away from the shark if it gets too close!
	3: Just stay idle and do not spend any energy if food and shark is far away!
	*/

	//Change angles at an increment of 30 degrees every time a shark gets close. Go from 90 degrees to 270 degrees
	if (prevAngle > 270) {
		prevAngle = 90;
	}

	//Do good stuff if we have sufficient energy
	if (CurrentRobotEnergy > MinEnergy)
	{
		if (SharkClosestDistance < RunFromShark)
		{
			//Shark too close, just run away!
			(*RobotExpendEnergy) = 30;
			(*RobotMoveAngle) = (prevAngle + SharkClosestAngle) % 360;
			prevAngle = angleInc + prevAngle;
		}
		else if (FoodClosestDistance < RunForFood)
		{
			//Food! Yay
			(*RobotExpendEnergy) = 30;
			(*RobotMoveAngle) = FoodClosestAngle;
		}
		else if (RobotClosestDistance < PersonalBubble) 
		{
			//Other bot is too close, move away from it
			(*RobotExpendEnergy) = 5;
			(*RobotMoveAngle) = (90 + RobotClosestAngle) % 360; 
		}
		else
		{
			//Nothing is close.. Move randomly to catch food by luck
			(*RobotExpendEnergy) = 10;
			(*RobotMoveAngle) = FoodClosestAngle; 
		}
	}
	//Survival Mode: Now we are low on energy. Food is Priority.
	else
	{
		//Go for food first! Need food to run away
		if (FoodClosestDistance < RunForFood)
		{
			(*RobotExpendEnergy) = 5 + FoodClosestDistance/10;
			(*RobotMoveAngle) = FoodClosestAngle;
		}

		//If shark gets too close, run. The dead cant eat!
		else if (SharkClosestDistance < RunFromShark)
		{
			(*RobotExpendEnergy) = 14;
			(*RobotMoveAngle) = (prevAngle + SharkClosestAngle) % 360;
			prevAngle = angleInc + prevAngle;
		}

		//Just stay idle until something comes close.
		else
		{
			(*RobotMoveAngle) = 0;
		}
	}
}



